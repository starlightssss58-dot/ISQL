package com.sahlisoft.sqlconsole

import java.sql.Connection
import java.sql.DriverManager
import java.sql.ResultSet
import java.sql.SQLException
import java.util.Properties

sealed class ResultBlock {
    abstract val sql: String

    data class Table(
        override val sql: String,
        val columns: List<String>,
        val rows: List<List<String?>>,
        val truncated: Boolean,
        val millis: Long,
    ) : ResultBlock()

    data class Message(override val sql: String, val text: String) : ResultBlock()
}

data class RunOutcome(val blocks: List<ResultBlock>, val error: String?, val millis: Long)

object Db {

    fun url(c: ConnConfig): String {
        val port = c.port.trim().ifBlank { "3050" }
        return "jdbc:firebirdsql://${c.host.trim()}:$port/${c.alias.trim()}"
    }

    fun open(c: ConnConfig): Connection {
        Class.forName("org.firebirdsql.jdbc.FBDriver")
        val props = Properties()
        props.setProperty("user", c.user.trim())
        props.setProperty("password", c.password)
        props.setProperty("encoding", c.charset)
        props.setProperty("connectTimeout", "10")
        props.setProperty("sqlDialect", c.dialect)
        if (c.wireCrypt != "Default") props.setProperty("wireCrypt", c.wireCrypt.uppercase())
        if (c.authPlugins != "Default") props.setProperty("authPlugins", c.authPlugins)
        DriverManager.setLoginTimeout(10)
        return DriverManager.getConnection(url(c), props)
    }

    fun test(c: ConnConfig): Pair<String, Boolean> {
        return try {
            open(c).use { conn ->
                conn.createStatement().use { st ->
                    st.executeQuery("SELECT 1 FROM RDB\$DATABASE").use { it.next() }
                }
                val md = conn.metaData
                Pair(
                    "Connected.\nServer: ${md.databaseProductName} ${md.databaseProductVersion}" +
                        "\nDriver: ${md.driverName} ${md.driverVersion}",
                    true,
                )
            }
        } catch (t: Throwable) {
            Pair(describe(t), false)
        }
    }

    fun run(c: ConnConfig, script: String): RunOutcome {
        val t0 = System.currentTimeMillis()
        val blocks = mutableListOf<ResultBlock>()
        var error: String? = null
        try {
            val max = (c.maxRows.trim().toIntOrNull() ?: 500).coerceIn(1, 100000)
            val timeout = (c.timeoutSec.trim().toIntOrNull() ?: 30).coerceIn(0, 3600)
            open(c).use { conn ->
                if (c.readOnly) conn.isReadOnly = true
                for (sql in SqlSplit.split(script)) {
                    if (c.readOnly && !SqlSplit.isRead(sql)) {
                        error = "Read-only mode is on. Only SELECT, WITH and EXECUTE statements are allowed.\n" +
                            "Turn it off in Settings to run other statements."
                        break
                    }
                    val s0 = System.currentTimeMillis()
                    try {
                        conn.createStatement().use { st ->
                            runCatching { st.queryTimeout = timeout }
                            st.maxRows = max + 1
                            if (st.execute(sql)) {
                                st.resultSet.use { rs -> blocks.add(readTable(sql, rs, max, s0)) }
                            } else {
                                blocks.add(ResultBlock.Message(sql, "OK. Rows affected: ${st.updateCount}"))
                            }
                        }
                    } catch (e: SQLException) {
                        error = describe(e) + "\n\nStatement: " + sql.take(200)
                        break
                    }
                }
            }
        } catch (t: Throwable) {
            error = describe(t)
        }
        return RunOutcome(blocks, error, System.currentTimeMillis() - t0)
    }

    private fun readTable(sql: String, rs: ResultSet, max: Int, startedAt: Long): ResultBlock.Table {
        val md = rs.metaData
        val n = md.columnCount
        val cols = (1..n).map { md.getColumnLabel(it) ?: "COL$it" }
        val rows = ArrayList<List<String?>>()
        var truncated = false
        while (rs.next()) {
            if (rows.size >= max) {
                truncated = true
                break
            }
            rows.add((1..n).map { cell(rs, it) })
        }
        return ResultBlock.Table(sql, cols, rows, truncated, System.currentTimeMillis() - startedAt)
    }

    private fun cell(rs: ResultSet, i: Int): String? = try {
        when (val v = rs.getObject(i)) {
            null -> null
            is String -> v.trimEnd()
            is ByteArray -> "[binary ${v.size} bytes]"
            is java.sql.Blob -> "[BLOB ${v.length()} bytes]"
            is java.sql.Clob -> v.getSubString(1, minOf(v.length(), 2000L).toInt())
            is java.math.BigDecimal -> v.toPlainString()
            else -> v.toString()
        }
    } catch (e: Exception) {
        "<error>"
    }

    fun describe(t: Throwable): String {
        val parts = mutableListOf<String>()
        var cur: Throwable? = t
        var guard = 0
        while (cur != null && guard < 4) {
            val m = cur.message ?: cur.javaClass.simpleName
            if (m !in parts) parts.add(m)
            cur = cur.cause
            guard++
        }
        if (t is SQLException) {
            t.nextException?.message?.let { if (it !in parts) parts.add(it) }
        }
        val text = parts.joinToString("\n")
        val h = hint(text)
        return if (h != null) "$text\n\nHint: $h" else text
    }

    private fun hint(message: String): String? {
        val x = message.lowercase()
        return when {
            "didn't find class" in x || "failed resolution" in x ->
                "A required library class is missing from the app build."
            "login" in x || "password" in x || "authentication" in x || "auth plugin" in x ->
                "Check the user and password. If they are correct, try Authentication plugins = Legacy_Auth, " +
                    "or change Wire encryption to match the server."
            "unsupported on-disk structure" in x || "unsupported ods" in x ->
                "The database file version is not supported by this driver."
            "refused" in x || "timed out" in x || "unable to complete network request" in x ||
                "unknownhost" in x || "unreachable" in x ->
                "Check the IP, port 3050, the server firewall and that the Firebird service is running."
            "i/o error" in x || "cannot attach" in x || "no such file" in x || "could not be opened" in x ->
                "Check the database alias (aliases.conf / databases.conf) or the database path."
            else -> null
        }
    }
}

object SqlSplit {

    /** Splits a script into statements on ';' outside quotes and comments. */
    fun split(script: String): List<String> {
        val first = script.trimStart().uppercase()
        if (first.startsWith("EXECUTE BLOCK")) {
            return listOf(script.trim().trimEnd(';'))
        }
        val out = mutableListOf<String>()
        val sb = StringBuilder()
        var quote: Char? = null
        var i = 0
        val n = script.length
        while (i < n) {
            val ch = script[i]
            val next = if (i + 1 < n) script[i + 1] else '\u0000'
            if (quote != null) {
                sb.append(ch)
                if (ch == quote) {
                    if (next == quote) {
                        sb.append(next)
                        i++
                    } else {
                        quote = null
                    }
                }
            } else if (ch == '\'' || ch == '"') {
                quote = ch
                sb.append(ch)
            } else if (ch == '-' && next == '-') {
                while (i < n && script[i] != '\n') i++
                sb.append('\n')
            } else if (ch == '/' && next == '*') {
                i += 2
                while (i + 1 < n && !(script[i] == '*' && script[i + 1] == '/')) i++
                i++
                sb.append(' ')
            } else if (ch == ';') {
                flush(sb, out)
            } else {
                sb.append(ch)
            }
            i++
        }
        flush(sb, out)
        return out
    }

    private fun flush(sb: StringBuilder, out: MutableList<String>) {
        val s = sb.toString().trim()
        if (s.isNotEmpty()) out.add(s)
        sb.setLength(0)
    }

    fun isRead(sql: String): Boolean {
        val w = sql.trimStart().takeWhile { it.isLetter() }.uppercase()
        return w == "SELECT" || w == "WITH" || w == "EXECUTE"
    }
}

object Templates {
    val all: List<Pair<String, String>> = listOf(
        "Tables" to
            "SELECT TRIM(RDB\$RELATION_NAME) AS TABLE_NAME\nFROM RDB\$RELATIONS\n" +
            "WHERE COALESCE(RDB\$SYSTEM_FLAG, 0) = 0 AND RDB\$VIEW_BLR IS NULL\nORDER BY 1",
        "Views" to
            "SELECT TRIM(RDB\$RELATION_NAME) AS VIEW_NAME\nFROM RDB\$RELATIONS\n" +
            "WHERE COALESCE(RDB\$SYSTEM_FLAG, 0) = 0 AND RDB\$VIEW_BLR IS NOT NULL\nORDER BY 1",
        "Columns of a table" to
            "SELECT TRIM(rf.RDB\$FIELD_NAME) AS COLUMN_NAME,\n" +
            "  CASE f.RDB\$FIELD_TYPE WHEN 7 THEN 'SMALLINT' WHEN 8 THEN 'INTEGER' WHEN 10 THEN 'FLOAT'\n" +
            "    WHEN 12 THEN 'DATE' WHEN 13 THEN 'TIME' WHEN 14 THEN 'CHAR' WHEN 16 THEN 'BIGINT'\n" +
            "    WHEN 27 THEN 'DOUBLE' WHEN 35 THEN 'TIMESTAMP' WHEN 37 THEN 'VARCHAR'\n" +
            "    WHEN 261 THEN 'BLOB' ELSE 'OTHER' END AS TYPE_NAME,\n" +
            "  f.RDB\$FIELD_LENGTH AS LEN,\n" +
            "  COALESCE(rf.RDB\$NULL_FLAG, 0) AS NOT_NULL\n" +
            "FROM RDB\$RELATION_FIELDS rf\n" +
            "JOIN RDB\$FIELDS f ON f.RDB\$FIELD_NAME = rf.RDB\$FIELD_SOURCE\n" +
            "WHERE rf.RDB\$RELATION_NAME = 'TABLE_NAME'\n" +
            "ORDER BY rf.RDB\$FIELD_POSITION",
        "First 100 rows" to "SELECT FIRST 100 * FROM TABLE_NAME",
        "Row count" to "SELECT COUNT(*) AS TOTAL FROM TABLE_NAME",
        "Stored procedures" to
            "SELECT TRIM(RDB\$PROCEDURE_NAME) AS PROCEDURE_NAME\nFROM RDB\$PROCEDURES\n" +
            "WHERE COALESCE(RDB\$SYSTEM_FLAG, 0) = 0\nORDER BY 1",
        "Generators" to
            "SELECT TRIM(RDB\$GENERATOR_NAME) AS GENERATOR_NAME\nFROM RDB\$GENERATORS\n" +
            "WHERE COALESCE(RDB\$SYSTEM_FLAG, 0) = 0\nORDER BY 1",
        "Indexes" to
            "SELECT TRIM(RDB\$INDEX_NAME) AS INDEX_NAME, TRIM(RDB\$RELATION_NAME) AS TABLE_NAME\n" +
            "FROM RDB\$INDICES\nWHERE COALESCE(RDB\$SYSTEM_FLAG, 0) = 0\nORDER BY 2, 1",
        "Server version" to
            "SELECT RDB\$GET_CONTEXT('SYSTEM', 'ENGINE_VERSION') AS VERSION FROM RDB\$DATABASE",
    )
}

fun ResultBlock.Table.toTsv(): String = buildString {
    append(columns.joinToString("\t"))
    append('\n')
    for (r in rows) {
        append(r.joinToString("\t") { (it ?: "").replace('\t', ' ').replace('\n', ' ') })
        append('\n')
    }
}
