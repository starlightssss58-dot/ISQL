package com.sahlisoft.sqlconsole

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class ConsoleVM(app: Application) : AndroidViewModel(app) {
    private val store = Store(app)

    var config by mutableStateOf(store.load())
        private set

    var sql by mutableStateOf("SELECT CURRENT_TIMESTAMP FROM RDB\$DATABASE")

    var running by mutableStateOf(false)
        private set
    var blocks by mutableStateOf<List<ResultBlock>>(emptyList())
        private set
    var selected by mutableIntStateOf(0)
    var status by mutableStateOf("Ready")
    var error by mutableStateOf<String?>(null)
        private set
    var lastOk by mutableStateOf<Boolean?>(null)
        private set
    var history by mutableStateOf(store.history())
        private set

    var testing by mutableStateOf(false)
        private set
    var testText by mutableStateOf<String?>(null)
        private set
    var testOk by mutableStateOf(false)
        private set

    fun saveConfig(c: ConnConfig) {
        store.save(c)
        config = c
        testText = null
    }

    fun clearTest() {
        testText = null
    }

    fun test(c: ConnConfig) {
        if (testing) return
        testing = true
        testText = null
        viewModelScope.launch {
            val r = withContext(Dispatchers.IO) { Db.test(c) }
            testText = r.first
            testOk = r.second
            testing = false
        }
    }

    fun run() {
        if (running) return
        val script = sql.trim()
        if (script.isEmpty()) return
        if (!config.isComplete) {
            error = "Set the server IP and database alias in Settings first."
            return
        }
        running = true
        error = null
        status = "Running…"
        val cfg = config
        viewModelScope.launch {
            val out = withContext(Dispatchers.IO) { Db.run(cfg, script) }
            blocks = out.blocks
            error = out.error
            selected = out.blocks.indexOfLast { it is ResultBlock.Table }.coerceAtLeast(0)
            val t = out.blocks.lastOrNull { it is ResultBlock.Table } as? ResultBlock.Table
            status = when {
                out.error != null -> "Failed after ${out.millis} ms"
                t != null -> "${t.rows.size} row(s)" +
                    (if (t.truncated) ", limited to ${cfg.maxRows} rows" else "") +
                    " in ${out.millis} ms"
                else -> "Done in ${out.millis} ms"
            }
            lastOk = out.error == null
            pushHistory(script)
            running = false
        }
    }

    fun clearResults() {
        blocks = emptyList()
        error = null
        status = "Ready"
    }

    private fun pushHistory(script: String) {
        val list = (listOf(script) + history.filter { it != script }).take(30)
        history = list
        store.saveHistory(list)
    }
}
