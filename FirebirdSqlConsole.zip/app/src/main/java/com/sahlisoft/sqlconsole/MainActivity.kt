package com.sahlisoft.sqlconsole

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.viewmodel.compose.viewModel

val Green = Color(0xFF1F9D63)
val Bg = Color(0xFFEEF2EF)
val TextC = Color(0xFF17231D)
val Muted = Color(0xFF62756A)
val ErrorRed = Color(0xFFC62828)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AppTheme { Root() }
        }
    }
}

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Green,
            onPrimary = Color.White,
            background = Bg,
            surface = Color.White,
            onSurface = TextC,
            secondaryContainer = Green.copy(alpha = 0.18f),
            onSecondaryContainer = TextC,
        ),
        content = content,
    )
}

@Composable
fun Root(vm: ConsoleVM = viewModel()) {
    var showSettings by rememberSaveable { mutableStateOf(!vm.config.isComplete) }
    if (showSettings) {
        BackHandler(enabled = vm.config.isComplete) { showSettings = false }
        SettingsScreen(vm = vm, onDone = { showSettings = false })
    } else {
        ConsoleScreen(vm = vm, onSettings = { showSettings = true })
    }
}
