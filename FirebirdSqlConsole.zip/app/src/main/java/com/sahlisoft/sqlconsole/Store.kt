package com.sahlisoft.sqlconsole

import android.content.Context

data class ConnConfig(
    val host: String = "",
    val port: String = "3050",
    val alias: String = "",
    val user: String = "SYSDBA",
    val password: String = "",
    val charset: String = "WIN1256",
    val wireCrypt: String = "Default",
    val authPlugins: String = "Default",
    val dialect: String = "3",
    val readOnly: Boolean = true,
    val maxRows: String = "500",
    val timeoutSec: String = "30",
) {
    val isComplete: Boolean get() = host.isNotBlank() && alias.isNotBlank()
}

class Store(context: Context) {
    private val p = context.applicationContext
        .getSharedPreferences("sqlconsole", Context.MODE_PRIVATE)

    private fun s(key: String, def: String): String = p.getString(key, def) ?: def

    fun load(): ConnConfig {
        val d = ConnConfig()
        return ConnConfig(
            host = s("host", d.host),
            port = s("port", d.port),
            alias = s("alias", d.alias),
            user = s("user", d.user),
            password = s("password", d.password),
            charset = s("charset", d.charset),
            wireCrypt = s("wireCrypt", d.wireCrypt),
            authPlugins = s("authPlugins", d.authPlugins),
            dialect = s("dialect", d.dialect),
            readOnly = p.getBoolean("readOnly", d.readOnly),
            maxRows = s("maxRows", d.maxRows),
            timeoutSec = s("timeoutSec", d.timeoutSec),
        )
    }

    fun save(c: ConnConfig) {
        p.edit()
            .putString("host", c.host.trim())
            .putString("port", c.port.trim())
            .putString("alias", c.alias.trim())
            .putString("user", c.user.trim())
            .putString("password", c.password)
            .putString("charset", c.charset)
            .putString("wireCrypt", c.wireCrypt)
            .putString("authPlugins", c.authPlugins)
            .putString("dialect", c.dialect)
            .putBoolean("readOnly", c.readOnly)
            .putString("maxRows", c.maxRows.trim())
            .putString("timeoutSec", c.timeoutSec.trim())
            .apply()
    }

    fun history(): List<String> =
        s("history", "").split('\u0001').filter { it.isNotBlank() }

    fun saveHistory(list: List<String>) {
        p.edit().putString("history", list.joinToString("\u0001")).apply()
    }
}
