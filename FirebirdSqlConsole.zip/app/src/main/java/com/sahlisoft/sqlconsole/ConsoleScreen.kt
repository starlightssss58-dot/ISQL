package com.sahlisoft.sqlconsole

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun ConsoleScreen(vm: ConsoleVM, onSettings: () -> Unit) {
    val clipboard = LocalClipboardManager.current
    var templatesOpen by remember { mutableStateOf(false) }
    var historyOpen by remember { mutableStateOf(false) }

    Column(
        Modifier
            .fillMaxSize()
            .background(Bg)
            .padding(12.dp),
    ) {
        // Header
        Row(verticalAlignment = Alignment.CenterVertically) {
            val dot = when (vm.lastOk) {
                true -> Green
                false -> ErrorRed
                null -> Muted
            }
            Box(
                Modifier
                    .size(10.dp)
                    .clip(CircleShape)
                    .background(dot),
            )
            Spacer(Modifier.width(8.dp))
            Text(
                "Firebird SQL Console",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = TextC,
                modifier = Modifier.weight(1f),
            )
            IconButton(onClick = onSettings) {
                Icon(Icons.Filled.Settings, contentDescription = "Settings")
            }
        }

        // Editor
        OutlinedTextField(
            value = vm.sql,
            onValueChange = { vm.sql = it },
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = 110.dp, max = 200.dp),
            textStyle = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 14.sp),
            placeholder = { Text("Write SQL here. Separate statements with ;") },
            keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.None),
            shape = RoundedCornerShape(14.dp),
        )

        // Actions
        Row(
            Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Button(onClick = { vm.run() }, enabled = !vm.running) {
                Icon(Icons.Filled.PlayArrow, contentDescription = null)
                Spacer(Modifier.width(4.dp))
                Text(if (vm.running) "Running…" else "Run")
            }
            Box {
                OutlinedButton(onClick = { templatesOpen = true }) { Text("Templates") }
                DropdownMenu(expanded = templatesOpen, onDismissRequest = { templatesOpen = false }) {
                    Templates.all.forEach { (name, sql) ->
                        DropdownMenuItem(
                            text = { Text(name) },
                            onClick = {
                                vm.sql = sql
                                templatesOpen = false
                            },
                        )
                    }
                }
            }
            Box {
                OutlinedButton(onClick = { historyOpen = true }) { Text("History") }
                DropdownMenu(expanded = historyOpen, onDismissRequest = { historyOpen = false }) {
                    if (vm.history.isEmpty()) {
                        DropdownMenuItem(text = { Text("No history yet") }, onClick = { historyOpen = false })
                    }
                    vm.history.forEach { item ->
                        DropdownMenuItem(
                            text = { Text(item.replace('\n', ' ').take(60), maxLines = 1) },
                            onClick = {
                                vm.sql = item
                                historyOpen = false
                            },
                        )
                    }
                }
            }
            OutlinedButton(onClick = { vm.sql = "" }) { Text("Clear") }
            OutlinedButton(
                onClick = {
                    val t = vm.blocks.getOrNull(vm.selected) as? ResultBlock.Table
                    if (t != null) {
                        clipboard.setText(AnnotatedString(t.toTsv()))
                        vm.status = "Copied ${t.rows.size} row(s)"
                    }
                },
            ) { Text("Copy result") }
        }

        // Status
        Text(vm.status, fontSize = 13.sp, color = Muted, modifier = Modifier.padding(bottom = 6.dp))

        // Error
        vm.error?.let { ErrorBox(it) }

        // Tabs when there is more than one result
        if (vm.blocks.size > 1) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(bottom = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                vm.blocks.forEachIndexed { i, b ->
                    val label = when (b) {
                        is ResultBlock.Table -> "#${i + 1} (${b.rows.size} rows)"
                        is ResultBlock.Message -> "#${i + 1} OK"
                    }
                    FilterChip(
                        selected = i == vm.selected,
                        onClick = { vm.selected = i },
                        label = { Text(label) },
                    )
                }
            }
        }

        // Result
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = Color.White,
            shadowElevation = 2.dp,
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
        ) {
            when (val cur = vm.blocks.getOrNull(vm.selected)) {
                is ResultBlock.Table -> TableView(cur)
                is ResultBlock.Message -> Text(
                    cur.text,
                    modifier = Modifier.padding(16.dp),
                    fontFamily = FontFamily.Monospace,
                    fontSize = 14.sp,
                    color = TextC,
                )
                null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("Results appear here", color = Muted)
                }
            }
        }
    }
}

@Composable
private fun ErrorBox(message: String) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = Color(0xFFFBEAEA),
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 8.dp),
    ) {
        SelectionContainer {
            Text(
                message,
                modifier = Modifier
                    .heightIn(max = 150.dp)
                    .verticalScroll(rememberScrollState())
                    .padding(12.dp),
                fontFamily = FontFamily.Monospace,
                fontSize = 13.sp,
                color = ErrorRed,
            )
        }
    }
}

@Composable
private fun TableView(t: ResultBlock.Table) {
    val widths: List<Dp> = remember(t) {
        t.columns.indices.map { i ->
            val longest = t.rows.take(100).maxOfOrNull { (it.getOrNull(i) ?: "<null>").length } ?: 0
            (maxOf(t.columns[i].length, longest) * 8 + 24).coerceIn(72, 300).dp
        }
    }
    Column(
        Modifier
            .fillMaxHeight()
            .horizontalScroll(rememberScrollState()),
    ) {
        Row(Modifier.background(Green.copy(alpha = 0.14f))) {
            Cell("#", 44.dp, bold = true)
            t.columns.forEachIndexed { i, c -> Cell(c, widths[i], bold = true) }
        }
        if (t.rows.isEmpty()) {
            Text("No rows.", color = Muted, modifier = Modifier.padding(16.dp))
        }
        LazyColumn(Modifier.weight(1f)) {
            itemsIndexed(t.rows) { r, row ->
                Row(Modifier.background(if (r % 2 == 0) Color.White else Color(0xFFF4F7F5))) {
                    Cell((r + 1).toString(), 44.dp, muted = true)
                    row.forEachIndexed { i, v ->
                        Cell(v ?: "<null>", widths[i], isNull = v == null)
                    }
                }
            }
        }
    }
}

@Composable
private fun Cell(
    text: String,
    width: Dp,
    bold: Boolean = false,
    muted: Boolean = false,
    isNull: Boolean = false,
) {
    Text(
        text = text,
        modifier = Modifier
            .width(width)
            .padding(horizontal = 8.dp, vertical = 6.dp),
        fontFamily = FontFamily.Monospace,
        fontSize = 13.sp,
        fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal,
        fontStyle = if (isNull) FontStyle.Italic else FontStyle.Normal,
        color = if (muted || isNull) Muted else TextC,
        maxLines = 2,
        overflow = TextOverflow.Ellipsis,
    )
}
