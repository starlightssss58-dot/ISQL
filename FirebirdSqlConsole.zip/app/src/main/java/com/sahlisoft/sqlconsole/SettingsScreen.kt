package com.sahlisoft.sqlconsole

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun SettingsScreen(vm: ConsoleVM, onDone: () -> Unit) {
    var d by remember { mutableStateOf(vm.config) }
    var showPass by remember { mutableStateOf(false) }

    Column(
        Modifier
            .fillMaxSize()
            .background(Bg),
    ) {
        Row(
            Modifier.padding(horizontal = 8.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            if (vm.config.isComplete) {
                IconButton(onClick = onDone) {
                    Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                }
            } else {
                Spacer(Modifier.width(12.dp))
            }
            Text("Connection settings", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = TextC)
        }

        Column(
            Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Field("Server IP", d.host, { d = d.copy(host = it) }, KeyboardType.Uri)
            Field("Port", d.port, { d = d.copy(port = it) }, KeyboardType.Number)
            Field(
                "Database alias", d.alias, { d = d.copy(alias = it) },
                supporting = "Alias from aliases.conf (Firebird 2.5) or databases.conf (3.0+). A full path also works.",
            )
            Field("User", d.user, { d = d.copy(user = it) })
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Field("Password", d.password, { d = d.copy(password = it) }, password = true, show = showPass)
                }
                TextButton(onClick = { showPass = !showPass }) { Text(if (showPass) "Hide" else "Show") }
            }

            ChipGroup(
                "Charset",
                listOf("WIN1256" to "WIN1256", "UTF8" to "UTF8", "WIN1252" to "WIN1252", "NONE" to "NONE"),
                d.charset,
            ) { d = d.copy(charset = it) }

            ChipGroup(
                "Wire encryption",
                listOf("Default" to "Default", "Disabled" to "Disabled", "Enabled" to "Enabled", "Required" to "Required"),
                d.wireCrypt,
            ) { d = d.copy(wireCrypt = it) }

            ChipGroup(
                "Authentication plugins",
                listOf(
                    "Default" to "Default",
                    "Srp256, Srp" to "Srp256,Srp",
                    "Srp" to "Srp",
                    "Legacy_Auth" to "Legacy_Auth",
                ),
                d.authPlugins,
            ) { d = d.copy(authPlugins = it) }

            ChipGroup("SQL dialect", listOf("Dialect 3" to "3", "Dialect 1" to "1"), d.dialect) {
                d = d.copy(dialect = it)
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Read-only mode", fontWeight = FontWeight.Bold, color = TextC)
                    Text(
                        "Only SELECT, WITH and EXECUTE are allowed, and the transaction is read-only.",
                        fontSize = 13.sp,
                        color = Muted,
                    )
                }
                Switch(checked = d.readOnly, onCheckedChange = { d = d.copy(readOnly = it) })
            }

            Field("Max rows per query", d.maxRows, { d = d.copy(maxRows = it) }, KeyboardType.Number)
            Field("Query timeout (seconds)", d.timeoutSec, { d = d.copy(timeoutSec = it) }, KeyboardType.Number)

            vm.testText?.let { text ->
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = if (vm.testOk) Color(0xFFE6F4EC) else Color(0xFFFBEAEA),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Text(
                        text,
                        modifier = Modifier.padding(12.dp),
                        fontFamily = FontFamily.Monospace,
                        fontSize = 13.sp,
                        color = if (vm.testOk) Color(0xFF1B5E3C) else ErrorRed,
                    )
                }
            }
            Spacer(Modifier.padding(4.dp))
        }

        Row(
            Modifier
                .fillMaxWidth()
                .background(Color.White)
                .padding(12.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            OutlinedButton(
                onClick = { vm.test(d) },
                enabled = !vm.testing && d.isComplete,
                modifier = Modifier.weight(1f),
            ) { Text(if (vm.testing) "Testing…" else "Test connection") }
            Button(
                onClick = {
                    vm.saveConfig(d)
                    onDone()
                },
                enabled = d.isComplete,
                modifier = Modifier.weight(1f),
            ) { Text("Save") }
        }
    }
}

@Composable
private fun Field(
    label: String,
    value: String,
    onChange: (String) -> Unit,
    keyboard: KeyboardType = KeyboardType.Text,
    password: Boolean = false,
    show: Boolean = false,
    supporting: String? = null,
) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        singleLine = true,
        modifier = Modifier.fillMaxWidth(),
        keyboardOptions = KeyboardOptions(keyboardType = keyboard, capitalization = KeyboardCapitalization.None),
        visualTransformation = if (password && !show) PasswordVisualTransformation() else VisualTransformation.None,
        supportingText = if (supporting != null) {
            { Text(supporting) }
        } else {
            null
        },
        shape = RoundedCornerShape(14.dp),
    )
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ChipGroup(
    title: String,
    options: List<Pair<String, String>>,
    selected: String,
    onSelect: (String) -> Unit,
) {
    Column {
        Text(title, fontSize = 13.sp, color = Muted, modifier = Modifier.padding(bottom = 4.dp))
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            options.forEach { (label, value) ->
                FilterChip(
                    selected = selected == value,
                    onClick = { onSelect(value) },
                    label = { Text(label) },
                )
            }
        }
    }
}
