plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.sahlisoft.sqlconsole"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.sahlisoft.sqlconsole"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
    kotlinOptions {
        jvmTarget = "11"
    }
    buildFeatures {
        compose = true
    }
    packaging {
        resources {
            excludes += setOf(
                "META-INF/versions/**",
                "META-INF/DEPENDENCIES",
                "META-INF/LICENSE*",
                "META-INF/NOTICE*",
                "javax/management/**",
                "net/java/dev/jna/**",
                "com/sun/jna/**",
                "win32-x86/**",
                "win32-x86-64/**",
                "linux-x86/**",
                "linux-x86-64/**",
                "darwin*/**",
            )
        }
        jniLibs { excludes += setOf("**/libjnidispatch.so") }
    }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.10.01"))
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-core")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.7")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")

    // Firebird JDBC driver (Firebird 2.5 to 5.0) + class missing on Android
    implementation("org.firebirdsql.jdbc:jaybird:5.0.5.java11") {
        exclude(group = "net.java.dev.jna")
    }
    implementation("javax.transaction:jta:1.1")
}
